<?php

namespace App;

use App\Screen;
use App\User;
use App\Polygon;
use Illuminate\Database\Eloquent\Model;

class Campaign extends Model
{
	const ADSERVER = 'ADSERVER';
	const DSP = 'DSP';

	const ACTIVA = 'ACTIVA';
	const PAUSADA = 'PAUSADA';
	const PROPUESTA = 'PROPUESTA';
	const AUTORIZADA = 'AUTORIZADA';
	const FINALIZADA = 'FINALIZADA';
	const CANCELADA = 'CANCELADA';

	protected $fillable = [
        'user_registry_id',
        'name',
        'comentary',
        'type_of_campaign',
        'investment',
        'start',
        'finish',
        'status',
        'customer_campaign_id',
        'country'
    ];

    /* Mutadores, cambiaran el valor antes de insertar valores */
    public function setNameAttribute($name) {
        $this->attributes['name'] = mb_strtolower($name);
    }

    public function setComentaryAttribute($comentary) {
        $this->attributes['comentary'] = mb_strtolower($comentary);
    }

    public function setTypeOfCampaignAttribute($type_of_campaign) {
        $this->attributes['type_of_campaign'] = strtoupper($type_of_campaign);
    }

    public function setStatusAttribute($status) {
        $this->attributes['status'] = strtoupper($status);
    }

    public function setCountryAttribute($country) {
        $this->attributes['country'] = mb_strtolower($country);
    }
    /* Mutadores, cambiaran el valor antes de insertar valores */

    public function screens() {
        return $this->belongsToMany(Screen::class, 'campaign_screens')->withPivot('flag');
    }

    public function seller() {
        return $this->belongsTo(User::class, 'user_registry_id');
    }

    public function customer() {
        return $this->belongsTo(User::class, 'customer_campaign_id');
    }

    public function polygons() {
        return $this->hasMany(Polygon::class);
    }

    public function pointsOfInterest() {
        return $this->hasMany(PointOfInterest::class);
    }
}