<?php

namespace App\Http\Controllers\Screen;

use App\Circuit;
use App\Company;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Screen;

class ScreenController extends ApiController
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware('can:screens.filtered')->only('filtered_screens');
        $this->middleware('can:store')->only('store');
        $this->middleware('can:show')->only('show');
        $this->middleware('can:update')->only('update');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function filtered_screens()
    {
        $screens = [];
        //'/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/'
        $reglas = [
            'ooh' => ['in:OUTDOOR,INDOOR'],
            'country' => ['regex:/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/'],
        ];

        $this->validate(request(), $reglas);

        if (request('ooh') && !request('country')) {
            $screens = Screen::where('ooh', request('ooh'))->get();
        }

        if (request('country') && !request('ooh')) {
            $screens = Screen::where('country', request('country'))->get();
        }

        if (request('country') && request('ooh')) {
            $screens = Screen::where(['ooh' => request('ooh'), 'country' => request('country')])->get();
        }

        if (!request('country') && !request('ooh')) {
            $screens = Screen::all();
        }

        return $this->showAll($screens);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $reglas = [
            'company_id' => ['required', 'integer'],
            'provider_screen_id' => ['required', 'string', 'min:5'],
            'ooh' => ['required', 'in:'.Screen::INDOOR.','.Screen::OUTDOOR],
            'type' => ['required', 'string'],
            'country' => ['required', 'string'],
            'state' => ['required', 'string'],
            'town_hall_delegation' => ['string'],
            'suburb' => ['string'],
            'street' => ['string'],
            'location_number' => ['string'],
            'postal_code' => ['string'],
            'latitude' => ['required', 'string'],
            'longitude' => ['required', 'string'],
            'vertical_horizontal' => ['required', 'in:'.Screen::VERTICAL.','.Screen::HORIZONTAL],
            'measure_in_pixels' => ['string'],
            'measured_in_meters' => ['string'],
            'average_monthly_impacts' => ['string'],
            'average_speed' => ['string'],
            'webcam' => ['required', 'in:SI,NO'],
            'photographic_witness' => ['required', 'in:SI,NO'],
            'spot_time_seconds' => ['integer'],
            'local_currency' => ['float'],
            'description' => ['string'],
            'purchase_remarks' => ['string'],
            'witness_time' => ['integer'],
            'url_img' => ['string'],
            'business_type' => ['string'],
            'business_name' => ['string'],
            'number_screens' => ['integer'],
            'display_name' => ['string'],
            'supports_image' => ['required', 'in:SI,NO'],
            'supports_video' => ['required', 'in:SI,NO'],
            'supports_image_gif' => ['required', 'in:SI,NO'],
            'minimum_days' => ['integer'],
            'minimum_spots' => ['integer'],
            'programatic_traditional' => ['required', 'in:'.Screen::PROGRAMATIC.','.Screen::TRADITIONAL],
            'tags' => ['string'],
            'black_list' => ['string'],
            'circuit_id' => ['integer'],
            'name_of_the_data_provider' => ['string'],
            'provider_data_id' => ['string']
        ];

        $this->validate(request(), $reglas);

        $company = Company::find(request('company_id'));

        if (!$company) {
            return $this->errorResponse('Empresa inexistente', 404);
        } else {
            if ($company->role != 'PROVEEDOR') {
                return $this->errorResponse('Debe de eligir una empresa de tipo proveedor', 404);
            }
        }

        if (request('circuit_id')) {
            if (!Circuit::find(request('circuit_id'))) {
                return $this->errorResponse('Circuito inexistente', 404);
            }
        }

        $screen = Screen::create(request()->all());

        return $this->showOne($screen, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Screen $screen)
    {
        return $this->showOne($screen);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Screen $screen)
    {
        $reglas = [
            'company_id' => ['integer'],
            'provider_screen_id' => ['string', 'min:5'],
            'ooh' => ['in:'.Screen::INDOOR.','.Screen::OUTDOOR],
            'type' => ['string'],
            'country' => ['string'],
            'state' => ['string'],
            'town_hall_delegation' => ['string'],
            'suburb' => ['string'],
            'street' => ['string'],
            'location_number' => ['string'],
            'postal_code' => ['string'],
            'latitude' => ['string'],
            'longitude' => ['string'],
            'vertical_horizontal' => ['in:'.Screen::VERTICAL.','.Screen::HORIZONTAL],
            'measure_in_pixels' => ['string'],
            'measured_in_meters' => ['string'],
            'average_monthly_impacts' => ['string'],
            'average_speed' => ['string'],
            'webcam' => ['in:SI,NO'],
            'photographic_witness' => ['in:SI,NO'],
            'spot_time_seconds' => ['integer'],
            'local_currency' => ['float'],
            'description' => ['string'],
            'purchase_remarks' => ['string'],
            'witness_time' => ['integer'],
            'url_img' => ['string'],
            'business_type' => ['string'],
            'business_name' => ['string'],
            'number_screens' => ['integer'],
            'display_name' => ['string'],
            'supports_image' => ['in:SI,NO'],
            'supports_video' => ['in:SI,NO'],
            'supports_image_gif' => ['in:SI,NO'],
            'minimum_days' => ['integer'],
            'minimum_spots' => ['integer'],
            'programatic_traditional' => ['in:'.Screen::PROGRAMATIC.','.Screen::TRADITIONAL],
            'tags' => ['string'],
            'black_list' => ['string'],
            'circuit_id' => ['integer'],
            'name_of_the_data_provider' => ['string'],
            'provider_data_id' => ['string']
        ];

        $this->validate(request(), $reglas);


        if (request('company_id')) {
            $company = Company::find(request('company_id'));
            if (!$company) {
                return $this->errorResponse('Empresa inexistente', 404);
            } else {
                if ($company->role != 'PROVEEDOR') {
                    return $this->errorResponse('Debe de eligir una empresa de tipo proveedor', 404);
                }
            }
            $screen->company_id = request('company_id');
        }

        if (request('circuit_id')) {
            if (!Circuit::find(request('circuit_id'))) {
                return $this->errorResponse('Circuito inexistente', 404);
            }
        }

        if (request('provider_screen_id')) {
            $screen->provider_screen_id = request('provider_screen_id');
        }

        if (request('ooh')) {
            $screen->ooh = request('ooh');
        }

        if (request('type')) {
            $screen->type = request('type');
        }

        if (request('country')) {
            $screen->country = request('country');
        }

        if (request('state')) {
            $screen->state = request('state');
        }

        if (request('town_hall_delegation')) {
            $screen->town_hall_delegation = request('town_hall_delegation');
        }

        if (request('suburb')) {
            $screen->suburb = request('suburb');
        }

        if (request('street')) {
            $screen->street = request('street');
        }

        if (request('location_number')) {
            $screen->location_number = request('location_number');
        }

        if (request('postal_code')) {
            $screen->postal_code = request('postal_code');
        }

        if (request('latitude')) {
            $screen->latitude = request('latitude');
        }

        if (request('longitude')) {
            $screen->longitude = request('longitude');
        }

        if (request('vertical_horizontal')) {
            $screen->vertical_horizontal = request('vertical_horizontal');
        }

        if (request('measure_in_pixels')) {
            $screen->measure_in_pixels = request('measure_in_pixels');
        }

        if (request('measured_in_meters')) {
            $screen->measured_in_meters = request('measured_in_meters');
        }

        if (request('average_monthly_impacts')) {
            $screen->average_monthly_impacts = request('average_monthly_impacts');
        }

        if (request('average_speed')) {
            $screen->average_speed = request('average_speed');
        }

        if (request('webcam')) {
            $screen->webcam = request('webcam');
        }

        if (request('photographic_witness')) {
            $screen->photographic_witness = request('photographic_witness');
        }

        if (request('spot_time_seconds')) {
            $screen->spot_time_seconds = request('spot_time_seconds');
        }

        if (request('local_currency')) {
            $screen->local_currency = request('local_currency');
        }

        if (request('description')) {
            $screen->description = request('description');
        }

        if (request('purchase_remarks')) {
            $screen->purchase_remarks = request('purchase_remarks');
        }

        if (request('witness_time')) {
            $screen->witness_time = request('witness_time');
        }

        if (request('url_img')) {
            $screen->url_img = request('url_img');
        }

        if (request('business_type')) {
            $screen->business_type = request('business_type');
        }

        if (request('business_name')) {
            $screen->business_name = request('business_name');
        }

        if (request('number_screens')) {
            $screen->number_screens = request('number_screens');
        }

        if (request('display_name')) {
            $screen->display_name = request('display_name');
        }

        if (request('supports_image')) {
            $screen->supports_image = request('supports_image');
        }

        if (request('supports_video')) {
            $screen->supports_video = request('supports_video');
        }

        if (request('supports_image_gif')) {
            $screen->supports_image_gif = request('supports_image_gif');
        }

        if (request('minimum_days')) {
            $screen->minimum_days = request('minimum_days');
        }

        if (request('minimum_spots')) {
            $screen->minimum_spots = request('minimum_spots');
        }

        if (request('programatic_traditional')) {
            $screen->programatic_traditional = request('programatic_traditional');
        }

        if (request('tags')) {
            $screen->tags = request('tags');
        }

        if (request('black_list')) {
            $screen->black_list = request('black_list');
        }

        if (request('circuit_id')) {
            $screen->circuit_id = request('circuit_id');
        }

        if (request('name_of_the_data_provider')) {
            $screen->name_of_the_data_provider = request('name_of_the_data_provider');
        }

        if (request('provider_data_id')) {
            $screen->provider_data_id = request('provider_data_id');
        }

        if (!$screen->isDirty()) {
            return $this->errorResponse('Se debe especificar al menos un valor diferente para actualizar', 422);
        }

        $screen->save();

        return $this->showOne($screen);
    }

}
