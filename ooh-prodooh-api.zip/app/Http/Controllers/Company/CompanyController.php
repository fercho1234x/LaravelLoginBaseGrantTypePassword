<?php

namespace App\Http\Controllers\Company;
use App\Company;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;

class CompanyController extends ApiController
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware('can:companies.index')->only('index');
        $this->middleware('can:companies.store')->only('store');
        $this->middleware('can:companies.show')->only('show');
        $this->middleware('can:companies.update')->only('update');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $companies = Company::all();
        return $this->showAll($companies);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $rules = [
            'name_company' => ['required', 'string', 'max:255'],
            'cell_phone' => ['string', 'min:5', 'max:20'],
            'phone_number' => ['string', 'min:5', 'max:20'],
            'country' => ['string', 'max:255'],
            'fiscal_key' => ['string', 'max:255'],
            'fiscal_address' => ['string', 'max:255'],
            'bussiness_name' => ['string', 'max:255'],
            'billing_email' => ['string', 'email', 'max:255'],
            'role' => ['string', 'max:100', 'in:'.Company::ADMINISTRATOR.','.Company::CLIENT.','.Company::RESELLER.','.Company::PROVIDER]
        ];
        $this->validate(request(), $rules);
        $company = Company::create(request()->all());
        return $this->showOne($company, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Company $company)
    {
        return $this->showOne($company);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Company $company)
    {
        $rules = [
            'role' => ['in:'.Company::ADMINISTRATOR.','.Company::CLIENT.','.Company::RESELLER.','.Company::PROVIDER]
        ];

        $this->validate(request(), $rules);

        /*$company->fill(request()->only([
            'name_company',
            'cell_phone',
            'phone_number',
            'country',
            'fiscal_key',
            'fiscal_address',
            'bussiness_name',
            'billing_email',
            'role'
        ]));*/

        if (request('name_company')) {
            $company->name_company = request('name_company');
        }

        if (request('cell_phone')) {
            $company->cell_phone = request('cell_phone');
        }

        if (request('phone_number')) {
            $company->phone_number = request('phone_number');
        }

        if (request('country')) {
            $company->country = request('country');
        }

        if (request('fiscal_key')) {
            $company->fiscal_key = request('fiscal_key');
        }

        if (request('fiscal_address')) {
            $company->fiscal_address = request('fiscal_address');
        }

        if (request('bussiness_name')) {
            $company->bussiness_name = request('bussiness_name');
        }

        if (request('billing_email')) {
            $company->billing_email = request('billing_email');
        }

        if (request('role')) {
            $company->role = request('role');
        }

        if($company->isClean()) {
            return $this->errorResponse('No se encontraron cambios', 422);
        }

        $company->save();

        return $this->showOne($company);
    }

}
