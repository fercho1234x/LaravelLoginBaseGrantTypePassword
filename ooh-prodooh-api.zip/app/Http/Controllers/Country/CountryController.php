<?php

namespace App\Http\Controllers\Country;

use App\Country;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ApiController;

class CountryController extends ApiController
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware('can:countries.index')->only('index');
        $this->middleware('can:countries.store')->only('store');
        $this->middleware('can:countries.show')->only('show');
        $this->middleware('can:countries.update')->only('update');
        $this->middleware('can:countries.destroy')->only('destroy');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $countries = Country::all();
        return $this->showAll($countries);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $rules = [
            'country_name' => ['required', 'string', 'max:255'],
            'dollar_change' => ['required', 'numeric'],
            'tax' => ['required', 'numeric'],
            'type_of_currency' => ['required', 'string', 'max:100']
        ];
        $this->validate(request(), $rules);
        $country = Country::create(request()->all());
        return $this->showOne($country, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Country  $country
     * @return \Illuminate\Http\Response
     */
    public function show(Country $country)
    {
        return $this->showOne($country);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Country  $country
     * @return \Illuminate\Http\Response
     */
    public function update(Country $country)
    {
        $rules = [
            'country_name' => ['string', 'max:255'],
            'dollar_change' => ['numeric'],
            'tax' => ['numeric'],
            'type_of_currency' => ['string', 'max:100']
        ];

        $this->validate(request(), $rules);

        if (request('country_name')) {
            $country->country_name = request('country_name');
        }

        if (request('dollar_change')) {
            $country->dollar_change = request('dollar_change');
        }

        if (request('tax')) {
            $country->tax = request('tax');
        }

        if (request('type_of_currency')) {
            $country->type_of_currency = request('type_of_currency');
        }

        if($country->isClean()) {
            return $this->errorResponse('No se encontraron cambios', 422);
        }

        $country->save();

        return $this->showOne($country);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Country  $country
     * @return \Illuminate\Http\Response
     */
    public function destroy(Country $country)
    {
        $country->delete();
        return $this->showOne($country);
    }
}
