<?php

namespace App\Http\Controllers\Circuit;

use App\Circuit;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;

class CircuitController extends ApiController
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware('can:circuits.index')->only('index');
        $this->middleware('can:circuits.store')->only('store');
        $this->middleware('can:circuits.show')->only('show');
        $this->middleware('can:circuits.update')->only('update');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $circuits = Circuit::all();
        return $this->showAll($circuits);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $rules = [
            'name' => ['required', 'string', 'max:255'],
        ];
        $this->validate(request(), $rules);
        $circuit = Circuit::create(request()->all());
        return $this->showOne($circuit, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Circuit $circuit)
    {
        return $this->showOne($circuit);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Circuit $circuit)
    {
        $rules = [
            'name' => ['string']
        ];

        $this->validate(request(), $rules);

        if (request('name')) {
            $circuit->name = request('name');
        }

        if($circuit->isClean()) {
            return $this->errorResponse('No se encontraron cambios', 422);
        }

        $circuit->save();

        return $this->showOne($circuit);
    }
}
