<?php

namespace App\Http\Controllers\User;
use Caffeinated\Shinobi\Models\Role;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use App\Company;
use App\User;

class UserController extends ApiController
{   

    /*
        Notas:
            * Añadir validaciones de empresa.
    */
    public function __construct()
    {
        parent::__construct();
        $this->middleware('can:users.index')->only('index');
        $this->middleware('can:users.store')->only('store');
        $this->middleware('can:users.show')->only('show');
        $this->middleware('can:users.update')->only('update');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = [];

        if (auth()->user()->hasRole('superadministrador') || auth()->user()->hasRole('administrador')) {
            $users = User::all();
        }

        if (auth()->user()->hasRole('administrador-ventas')) {
            $users = auth()->user()->users_admin;
        }

        if (auth()->user()->hasRole('vendedor-costos') || auth()->user()->hasRole('vendedor')) {
            $users = auth()->user()->customers;
        }

        return $this->showAll($users);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $rules = [
            'company_id' => ['required', 'integer'],
            'name' => ['required', 'string', 'max:255'],
            'surnames' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'img_profile' => ['image'],
            'role' => ['required', 'integer']
        ];

        $this->validate(request(), $rules);

        if (!Company::find(request('company_id'))) {
            return $this->errorResponse('Empresa inexistente', 404);
        }

        $user_registry_id = auth()->user()->id;
        $admin_registry_id;

        if (auth()->user()->hasRole('superadministrador') || auth()->user()->hasRole('administrador') || auth()->user()->hasRole('administrador-ventas')) {
            $admin_registry_id = auth()->user()->id;
        } else {
            $admin_registry_id = auth()->user()->admin_registry_id;
        }

        $fields = request()->all();
        $fields['password'] = bcrypt($fields['password']);
        $fields['user_registry_id'] = $user_registry_id;
        $fields['admin_registry_id'] = $admin_registry_id;

        if (!request()->hasFile('img_profile')) {
            $fields['img_profile'] = 'default.png';
        } else {
            $fields['img_profile'] = request('img_profile')->store('', 'users_images');
        }

        $user = User::create($fields);

        // Simulacion de obtener un role
        $role = Role::find(request('role'));
        $slug = 'suspendido';

        if ($role) {
            $slug = $role->slug;
            if (auth()->user()->hasRole('administrador-ventas')) {
                if ($slug == 'vendedor-costos' || $slug == 'vendedor' || $slug == 'cliente-costos' || $slug == 'cliente' || $slug == 'suspendido') {
                    $slug = $slug;
                } else {
                    $slug = 'suspendido';
                }
            } else if (auth()->user()->hasRole('vendedor-costos')) {
                if ($slug == 'cliente-costos' || $slug == 'cliente' || $slug == 'suspendido') {
                    $slug = $slug;
                } else {
                    $slug = 'suspendido';
                }
            } else if (auth()->user()->hasRole('vendedor')) {
                if ($slug == 'cliente' || $slug == 'suspendido') {
                    $slug = $slug;
                } else {
                    $slug = 'suspendido';
                }
            } else {
                $slug = 'suspendido';
            }
        }

        $user->assignRoles($slug);

        return $this->showOne($user, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        if (auth()->user()->hasRole('superadministrador') || auth()->user()->hasRole('administrador')) {
            $user = $user;
        } else if (auth()->user()->hasRole('administrador-ventas')) {
            if ($user->admin_registry_id != auth()->user()->id) {
                return $this->errorResponse('No tienes control de este usuario', 403);
            }
        } else if (auth()->user()->hasRole('vendedor-costos') || auth()->user()->hasRole('vendedor')) {
            if ($user->user_registry_id != auth()->user()->id) {
                return $this->errorResponse('No tienes control de este usuario', 403);
            }
        } else {
            return $this->errorResponse('No tienes control de este usuario', 403);
        }

        return $this->showOne($user);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(User $user)
    {

        if (auth()->user()->hasRole('superadministrador') || auth()->user()->hasRole('administrador')) {
            $user = $user;
        } else if (auth()->user()->hasRole('administrador-ventas')) {
            
            if ($user->id != auth()->user()->id) {
                if ($user->admin_registry_id != auth()->user()->id) {
                    return $this->errorResponse('No tienes control de este usuario', 403);
                }
            }

        } else if (auth()->user()->hasRole('vendedor-costos') || auth()->user()->hasRole('vendedor')) {
            
            if ($user->id != auth()->user()->id) {
                if ($user->user_registry_id != auth()->user()->id) {
                    return $this->errorResponse('No tienes control de este usuario', 403);
                }
            }

        } else if (auth()->user()->hasRole('cliente-costos') || auth()->user()->hasRole('cliente')) {
            
            if ($user->id != auth()->user()->id) {
                return $this->errorResponse('No tienes control de este usuario', 403);
            }

        } else {

            return $this->errorResponse('No tienes control de este usuario', 403);

        }

        $reglas = [
            'company_id' => ['integer'],
            'name' => ['string', 'max:255'],
            'surnames' => ['string', 'max:255'],
            'email' => 'email|unique:users,email,' . $user->id,
            'password' => 'min:6|confirmed',
            'img_profile' => ['image']
        ];

        $this->validate(request(), $reglas);

        if (request('name')) {
            $user->name = request('name');
        }

        if (request('surnames')) {
            $user->surnames = request('surnames');
        }

        if (request('company_id')) {
            if (!Company::find(request('company_id'))) {
                return $this->errorResponse('Empresa inexistente', 404);
            }
            $user->company_id = request('company_id');
        }

        if (request('email') && $user->email != request('email')) {
            $user->email = request('email');
        }

        if (request('password')) {
            $user->password = bcrypt(request('password'));
        }

        /* Para actualizar la imagen se debe de falsear la peticion, realizando una peticion POST con un campo _method indicando el metodo PUT */
        if (request()->hasFile('img_profile')) {
            if ($user->img_profile != 'default.png') {
                Storage::disk('users_images')->delete($user->img_profile);
            }
            $user->img_profile = request('img_profile')->store('', 'users_images');
        }

        if (!$user->isDirty()) {
            return $this->errorResponse('Se debe especificar al menos un valor diferente para actualizar', 422);
        }

        $user->save();

        return $this->showOne($user);
    }

    public function logout() {
        if (request()->user()->token()->revoke()) {
            return $this->message('Logout', 200);
        } else {
            return $this->errorResponse('Error al cerrar session, contacta a un administrador', 400);
        }
    }
}
