<?php

namespace App\Http\Controllers\Campaign;

use App\Campaign;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;

class CampaignController extends ApiController
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware('can:campaigns.index')->only('index');
        $this->middleware('can:campaigns.store')->only('store');
        $this->middleware('can:campaigns.show')->only('show');
        $this->middleware('can:campaigns.update')->only('update');
        $this->middleware('can:campaigns.destroy')->only('destroy');
        $this->middleware('can:campaigns.duplicate')->only('duplicate');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $campaings = Campaign::all();
        return $this->showAll($campaings);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        /*
            Realizar las validaciones para los usuarios
            para saber cuales es vendedor y cual es cliente

            Validacion para poder asignar una campaña a otro usuario
        */
        $rules = [
            'user_registry_id' => ['required', 'integer'],
            'name' => ['required', 'string'],
            'comentary' => ['required'],
            'type_of_campaign' => ['required', 'in:'.Campaign::ADSERVER.','.Campaign::DSP],
            'investment' => ['required', 'numeric'],
            'start' => ['required', 'regex:/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/'],
            'finish' => ['required', 'regex:/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/'],
            'status' => ['required', 'in:'.Campaign::ACTIVA.','.Campaign::PAUSADA.','.Campaign::PROPUESTA.','.Campaign::AUTORIZADA.','.Campaign::FINALIZADA.','.Campaign::CANCELADA],
            'customer_campaign_id' => ['required', 'integer'],
            'country' => ['required', 'string']
        ];
        $this->validate(request(), $rules);

        if (!User::find(request('user_registry_id')) || !User::find(request('customer_campaign_id'))) {
            return $this->errorResponse('Usuario inexistente', 404);
        }

        $campaign = Campaign::create(request()->all());
        return $this->showOne($campaign, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Campaign $campaign)
    {
        return $this->showOne($campaign->customer);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Campaign $campaign)
    {
        $rules = [
            'user_registry_id' => ['integer'],
            'name' => ['string'],
            'comentary' => ['string'],
            'type_of_campaign' => ['in:'.Campaign::ADSERVER.','.Campaign::DSP],
            'investment' => ['numeric'],
            'start' => ['regex:/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/'],
            'finish' => ['regex:/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/'],
            'status' => ['in:'.Campaign::ACTIVA.','.Campaign::PAUSADA.','.Campaign::PROPUESTA.','.Campaign::AUTORIZADA.','.Campaign::FINALIZADA.','.Campaign::CANCELADA],
            'customer_campaign_id' => ['integer'],
            'country' => ['string']
        ];
        $this->validate(request(), $rules);

        if (request('user_registry_id')) {
            if (!User::find(request('user_registry_id'))) {
                return $this->errorResponse('Usuario inexistente', 404);
            } else {
                $campaign->user_registry_id = request('user_registry_id');
            }
        }

        if (request('name')) {
            $campaign->name = request('name');
        }

        if (request('comentary')) {
            $campaign->comentary = request('comentary');
        }

        if (request('type_of_campaign')) {
            $campaign->type_of_campaign = request('type_of_campaign');
        }

        if (request('investment')) {
            $campaign->investment = request('investment');
        }

        if (request('start')) {
            $campaign->start = request('start');
        }

        if (request('finish')) {
            $campaign->finish = request('finish');
        }

        if (request('status')) {
            $campaign->status = request('status');
        }

        if (request('customer_campaign_id')) {
            if (!User::find(request('customer_campaign_id'))) {
                return $this->errorResponse('Usuario inexistente', 404);
            } else {
                $campaign->customer_campaign_id = request('customer_campaign_id');
            }
        }

        if (request('country')) {
            $campaign->country = request('country');
        }

        if($campaign->isClean()) {
            return $this->errorResponse('No se encontraron cambios', 422);
        }

        $campaign->save();

        return $this->showOne($campaign);
    }

    /**
    Realizar las validaciones correspondientes al eliminar una campaña
    dicha campaña lleva relacion con usuarios, pantallas, poligonos, etc
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Campaign $campaign)
    {
        //
    }

    public function duplicate(Campaign $campaign) {

        $duplicated_campaign = $campaign->replicate();

        $duplicated_campaign['name'] = 'copia '.date("Y-m-d").' '.$duplicated_campaign['name'];

        $duplicated_campaign->push();

        $screens_campaign = $campaign->screens;
        $points_of_interest_campaign = $campaign->pointsOfInterest;
        $polygons_campaign = $campaign->polygons;

        if (sizeof($screens_campaign) > 0) {
            foreach ($screens_campaign as $screen) {
                $duplicated_campaign->screens()->syncWithoutDetaching($screen->id);
            }
        }

        if (sizeof($points_of_interest_campaign) > 0) {
            foreach ($points_of_interest_campaign as $point_of_interest_campaign) {
                $duplicated_campaign->pointsOfInterest()->create($point_of_interest_campaign->toArray());
            }
        }

        if (sizeof($polygons_campaign) > 0) {
            foreach ($polygons_campaign as $polygon_campaign) {
                $duplicated_campaign->polygons()->create($polygon_campaign->toArray());
            }
        }

        return $this->showOne($duplicated_campaign);
    }
}
