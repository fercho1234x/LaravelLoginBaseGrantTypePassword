<?php

namespace App\Http\Controllers\Campaign;

use App\Campaign;
use App\Polygon;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ApiController;

class CampaignPolygonController extends ApiController
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware('can:campaigns.polygons.index')->only('index');
        $this->middleware('can:campaigns.polygons.store')->only('store');
        $this->middleware('can:campaigns.polygons.destroy')->only('destroy');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Campaign $campaign)
    {
        $polygons = $campaign->polygons;
        return $this->showAll($polygons);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Campaign $campaign)
    {
        $rules = [
            'polygons' => ['required']
        ];

        $this->validate(request(), $rules);

        $polygons_array_decode = json_decode(request('polygons'), true);

        if (!is_array($polygons_array_decode)) {
            return $this->errorResponse('Error, array de poligonos invalido', 406);
        }

        $campaign->polygons()->delete();

        foreach ($polygons_array_decode as $key => $polygon_data) {
            $polygon_json = json_encode($polygon_data);
            if ($polygon_json) {
                $polygon = Polygon::create([
                    'campaign_id' => $campaign->id,
                    'polygon'  => $polygon_json
                ]);
            }
        }

        return $this->message('Poligonos agregados correctamente', 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Polygon  $polygon
     * @return \Illuminate\Http\Response
     */
    public function destroy(Campaign $campaign, Polygon $polygon)
    {
        if (!$campaign->polygons()->find($polygon->id)) {
            return $this->errorResponse('El poligono no existe en la campaña', 404);
        }

        $polygon->delete();

        return $this->showAll($campaign->polygons);
    }
}
