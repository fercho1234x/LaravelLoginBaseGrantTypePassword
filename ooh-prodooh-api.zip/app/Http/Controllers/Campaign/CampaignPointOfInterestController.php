<?php

namespace App\Http\Controllers\Campaign;

use App\Campaign;
use App\PointOfInterest;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\Validator;

class CampaignPointOfInterestController extends ApiController
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware('can:campaigns.pointsofinterest.index')->only('index');
        $this->middleware('can:campaigns.pointsofinterest.store')->only('store');
        $this->middleware('can:campaigns.pointsofinterest.destroy')->only('destroy');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Campaign $campaign)
    {
        $pointsOfInterest = $campaign->pointsOfInterest;
        return $this->showAll($pointsOfInterest);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Campaign $campaign)
    {
        $rules = [
            'pointsOfInterest' => ['required']
        ];

        $this->validate(request(), $rules);

        $points_of_interst_array_decode = json_decode(request('pointsOfInterest'), true);

        if (!is_array($points_of_interst_array_decode)) {
            return $this->errorResponse('Error, array de puntos de interes invalido', 406);
        }

        $campaign->pointsOfInterest()->delete();

        foreach ($points_of_interst_array_decode as $key => $point_interest_data) {
            $validate = Validator::make($point_interest_data, [
                'google_id' => ['required', 'string', 'max:255'],
                'name' => ['required', 'string', 'max:255'],
                'address' => ['required', 'string', 'max:255'],
                'latitude' => ['required', 'regex:/^-?([1-8]?[1-9]|[1-9]0)\.{1}\d{1,15}/'],
                'longitude' => ['required', 'regex:/^-?(([-+]?)([\d]{1,3})((\.)(\d+))?)/'],
            ]);

            if ($validate->fails()) {
                return $this->errorResponse('Error, datos enviados erroneos Google ID: '.$point_interest_data['google_id'], 406);
            } else {
                $pointOfInterest = PointOfInterest::create([
                    'campaign_id' => $campaign->id,
                    'google_id'  => $point_interest_data['google_id'],
                    'name'  => $point_interest_data['name'],
                    'address'  => $point_interest_data['address'],
                    'latitude'  => $point_interest_data['latitude'],
                    'longitude'  => $point_interest_data['longitude']
                ]);
            }
        }

        return $this->showAll($campaign->pointsOfInterest);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Campaign  $campaign
     * @return \Illuminate\Http\Response
     */
    public function destroy(Campaign $campaign, PointOfInterest $pointsofinterest)
    {
        if (!$campaign->pointsOfInterest()->find($pointsofinterest->id)) {
            return $this->errorResponse('El punto de interes no existe en la campaña', 404);
        }

        $pointsofinterest->delete();

        return $this->showAll($campaign->pointsOfInterest);
    }
}
