<?php

namespace App\Http\Controllers\Campaign;

use App\Campaign;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Screen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CampaignScreenController extends ApiController
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware('can:campaigns.screens.index')->only('index');
        $this->middleware('can:campaigns.screens.store')->only('store');
        $this->middleware('can:campaigns.screens.destroy')->only('destroy');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Campaign $campaign)
    {
        $screens = $campaign->screens;
        return $this->showAll($screens);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Campaign $campaign)
    {
        // {"screens_ids":[12,212,212,232,23,2222]}
        $rules = [
            'screens' => ['required']
        ];

        $this->validate(request(), $rules);

        $screens_json = request('screens', null);
        $screens_decode = json_decode($screens_json, true);

        $validate = Validator::make($screens_decode, [
            'screens_ids.*' => ['numeric']
        ]);

        if ($validate->fails()) {
            return $this->errorResponse('Error, ids de pantallas deben ser numericos', 400);
        }

        foreach ($screens_decode['screens_ids'] as $key => $pantalla_id) {
            if (Screen::find($pantalla_id)) {
                $campaign->screens()->syncWithoutDetaching($pantalla_id);
            }
        }

        return $this->message('Pantallas agregadas', 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Campaign  $campaign
     * @return \Illuminate\Http\Response
     */
    public function destroy(Campaign $campaign, Screen $screen)
    {
        if (!$campaign->screens()->find($screen->id)) {
            return $this->errorResponse('La pantalla no existe en la campaña', 404);
        }

        $campaign->screens()->detach($screen->id);
        return $this->showAll($campaign->screens);
    }
}
