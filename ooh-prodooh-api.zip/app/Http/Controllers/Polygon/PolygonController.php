<?php

namespace App\Http\Controllers\Polygon;

use App\Http\Controllers\Controller;
use App\Polygon;
use Illuminate\Http\Request;

use App\Http\Controllers\ApiController;

class PolygonController extends ApiController
{

    
}
