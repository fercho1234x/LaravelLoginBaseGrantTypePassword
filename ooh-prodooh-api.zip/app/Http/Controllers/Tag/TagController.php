<?php

namespace App\Http\Controllers\Tag;

use App\Http\Controllers\ApiController;
use App\Http\Controllers\Controller;
use App\Tag;

class TagController extends ApiController
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware('can:tags.index')->only('index');
        $this->middleware('can:tags.store')->only('store');
        $this->middleware('can:tags.show')->only('show');
        $this->middleware('can:tags.update')->only('update');
        $this->middleware('can:tags.destroy')->only('destroy');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tags = Tag::all();
        return $this->showAll($tags);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $rules = [
            'title_tag' => ['required', 'string', 'max:255'],
        ];
        $this->validate(request(), $rules);
        $tag = Tag::create(request()->all());
        return $this->showOne($tag, 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Tag  $tag
     * @return \Illuminate\Http\Response
     */
    public function show(Tag $tag)
    {
        return $this->showOne($tag);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Tag  $tag
     * @return \Illuminate\Http\Response
     */
    public function update(Tag $tag)
    {
        $rules = [
            'title_tag' => ['string']
        ];

        $this->validate(request(), $rules);

        if (request('title_tag')) {
            $tag->title_tag = request('title_tag');
        }

        if($tag->isClean()) {
            return $this->errorResponse('No se encontraron cambios', 422);
        }

        $tag->save();

        return $this->showOne($tag);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Tag  $tag
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tag $tag)
    {
        $tag->delete();
        return $this->showOne($tag);
    }
}
