<?php

namespace App;

use App\Screen;
use App\User;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
	const ADMINISTRATOR = 'ADMINISTRATOR';
	const CLIENT = 'CLIENT';
	const RESELLER = 'RESELLER';
	const PROVIDER = 'PROVIDER';

	/**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name_company', 'cell_phone', 'phone_number', 'country', 'fiscal_key', 'fiscal_address', 'bussiness_name', 'billing_email', 'role',
    ];

    /* Mutadores, cambiaran el valor antes de insertar valores */
    public function setNameCompanyAttribute($name_company) {
        $this->attributes['name_company'] = strtolower($name_company);
    }

    public function setCountryAttribute($country) {
        $this->attributes['country'] = strtolower($country);
    }

    public function setFiscalKeyAttribute($fiscal_key) {
        $this->attributes['fiscal_key'] = strtolower($fiscal_key);
    }

    public function setFiscalAddressAttribute($fiscal_address) {
        $this->attributes['fiscal_address'] = strtolower($fiscal_address);
    }

    public function setBussinessNameAttribute($bussiness_name) {
        $this->attributes['bussiness_name'] = strtolower($bussiness_name);
    }

    public function setBillingEmailAttribute($billing_email) {
        $this->attributes['billing_email'] = strtolower($billing_email);
    }

    /* Accesores, modificaran el valor despues de obtenerlo */
    public function getNameCompanyAttribute($name_company) {
        return ucwords($name_company);
    }

    public function getCountryAttribute($country) {
        return ucwords($country);
    }

    public function users() {
        return $this->hasMany(User::class);
    }

    public function screens() {
        return $this->hasMany(Screen::class);
    }
}
