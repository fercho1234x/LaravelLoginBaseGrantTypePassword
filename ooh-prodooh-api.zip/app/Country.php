<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
     protected $fillable = [
        'country_name',
        'dollar_change',
        'tax',
        'type_of_currency'
    ];

    /* Mutadores, cambiaran el valor antes de insertar valores */
    public function setCountryNameAttribute($country_name) {
        $this->attributes['country_name'] = mb_strtolower($country_name);
    }

    public function setTypeOfCurrencyAttribute($type_of_currency) {
        $this->attributes['type_of_currency'] = mb_strtolower($type_of_currency);
    }
}
