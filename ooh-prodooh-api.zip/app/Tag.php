<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
	/* Mutadores, cambiaran el valor antes de insertar valores */
    public function setTitleTagAttribute($title_tag) {
        $this->attributes['title_tag'] = mb_strtolower($title_tag);
    }

    protected $fillable = [
        'title_tag'
    ];
}
