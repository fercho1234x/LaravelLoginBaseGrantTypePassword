<?php

namespace App;

use App\Campaign;
use App\Circuit;
use App\Company;
use Illuminate\Database\Eloquent\Model;

class Screen extends Model
{
    const INDOOR = 'INDOOR';
	const OUTDOOR = 'OUTDOOR';

	const VERTICAL = 'VERTICAL';
	const HORIZONTAL = 'HORIZONTAL';

	const PROGRAMATIC = 'PROGRAMATIC';
	const TRADITIONAL = 'TRADITIONAL';

	/**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'company_id',
		'provider_screen_id',
		'ooh',
		'type',
		'country',
		'state',
		'town_hall_delegation',
		'suburb',
		'street',
		'location_number',
		'postal_code',
		'latitude',
		'longitude',
		'vertical_horizontal',
		'measure_in_pixels',
		'measured_in_meters',
		'average_monthly_impacts',
		'average_speed',
		'webcam',
		'photographic_witness',
		'spot_time_seconds',
		'local_currency',
		'description',
		'purchase_remarks',
		'witness_time',
		'url_img',
		'business_type',
		'business_name',
		'number_screens',
		'display_name',
		'supports_image',
		'supports_video',
		'supports_image_gif',
		'minimum_days',
		'minimum_spots',
		'programatic_traditional',
		'tags',
		'black_list',
		'circuit_id',
		'name_of_the_data_provider',
		'provider_data_id'
    ];

    /* Mutadores, cambiaran el valor antes de insertar valores */
    public function setProviderScreenIdAttribute($provider_screen_id) {
        $this->attributes['provider_screen_id'] = strtolower($provider_screen_id);
    }

    public function setOohAttribute($ooh) {
        $this->attributes['ooh'] = strtoupper($ooh);
    }

    public function setTypeAttribute($type) {
        $this->attributes['type'] = mb_strtolower($type);
    }

    public function setCountryAttribute($country) {
        $this->attributes['country'] = mb_strtolower($country);
    }

    public function setStateAttribute($state) {
        $this->attributes['state'] = mb_strtolower($state);
    }

    public function setTownHallDelegationAttribute($billing_email) {
        $this->attributes['billing_email'] = mb_strtolower($billing_email);
    }

    public function setSuburdAttribute($suburb) {
        $this->attributes['suburb'] = mb_strtolower($suburb);
    }

    public function setStreetAttribute($street) {
        $this->attributes['street'] = mb_strtolower($street);
    }

    public function setLocationNumberAttribute($location_number) {
        $this->attributes['location_number'] = mb_strtolower($location_number);
    }

    public function setPostalCodeAttribute($postal_code) {
        $this->attributes['postal_code'] = strtolower($postal_code);
    }

    public function setVerticalHorizontalAttribute($vertical_horizontal) {
        $this->attributes['vertical_horizontal'] = strtoupper($vertical_horizontal);
    }

    public function setWebcamAttribute($webcam) {
        $this->attributes['webcam'] = strtolower($webcam);
    }

    public function setPhotographicWitnessAttribute($photographic_witness) {
        $this->attributes['photographic_witness'] = strtolower($photographic_witness);
    }

    public function setDescriptionAttribute($description) {
        $this->attributes['description'] = mb_strtolower($description);
    }

    public function setPurchaseRemarksAttribute($purchase_remarks) {
        $this->attributes['purchase_remarks'] = mb_strtolower($purchase_remarks);
    }

    public function setWitnessTimeAttribute($witness_time) {
        $this->attributes['witness_time'] = mb_strtolower($witness_time);
    }

    public function setUrlImgAttribute($url_img) {
        $this->attributes['url_img'] = strtolower($url_img);
    }

    public function setBusinessTypeAttribute($business_type) {
        $this->attributes['business_type'] = mb_strtolower($business_type);
    }

    public function setBusinessNameAttribute($business_name) {
        $this->attributes['business_name'] = mb_strtolower($business_name);
    }

    public function setDisplayNameAttribute($display_name) {
        $this->attributes['display_name'] = mb_strtolower($display_name);
    }

    public function setSupportsImageAttribute($supports_image) {
        $this->attributes['supports_image'] = strtolower($supports_image);
    }

    public function setSupportsVideoAttribute($supports_video) {
        $this->attributes['supports_video'] = strtolower($supports_video);
    }

    public function setSupportsImageGifAttribute($supports_image_gif) {
        $this->attributes['supports_image_gif'] = strtolower($supports_image_gif);
    }

    public function setProgramaticTraditionalAttribute($programatic_traditional) {
        $this->attributes['programatic_traditional'] = strtoupper($programatic_traditional);
    }

    public function setTagsAttribute($tags) {
        $this->attributes['tags'] = mb_strtolower($tags);
    }

    public function setBlackListAttribute($black_list) {
        $this->attributes['black_list'] = mb_strtolower($black_list);
    }

    public function setCircuitIdAttribute($circuit_id) {
        $this->attributes['circuit_id'] = strtolower($circuit_id);
    }

    public function setNameOfTheDataProviderAttribute($name_of_the_data_provider) {
        $this->attributes['name_of_the_data_provider'] = mb_strtolower($name_of_the_data_provider);
    }

    public function setProviderDataIdAttribute($provider_data_id) {
        $this->attributes['provider_data_id'] = strtolower($provider_data_id);
    }

    public function company() {
        return $this->belongsTo(Company::class);
    }

    public function circuit() {
        return $this->belongsTo(Circuit::class);
    }

    public function campaigns() {
        return $this->belongsToMany(Campaign::class, 'campaign_screens')->withPivot('flag');
    }
}
