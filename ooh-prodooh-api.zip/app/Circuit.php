<?php

namespace App;

use App\Screen;
use Illuminate\Database\Eloquent\Model;

class Circuit extends Model
{
    protected $fillable = [
        'name'
    ];

    public function screens() {
        return $this->hasMany(Screen::class);
    }
}
