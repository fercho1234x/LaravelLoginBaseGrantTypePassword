<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PointOfInterest extends Model
{
    protected $table = 'points_of_interest';

    protected $fillable = [
        'campaign_id', 'google_id', 'name', 'address', 'latitude', 'longitude'
    ];
}
