<?php

use Illuminate\Database\Seeder;
use Caffeinated\Shinobi\Models\Permission;

class PermissionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Users
        Permission::create([
    		'name'			=>			'Ver usuarios',
    		'slug'			=>			'users.index',
    		'description'	=>			'Listara todos los usuarios'
    	]);

    	Permission::create([
    		'name'			=>			'Crear usuarios',
    		'slug'			=>			'users.store',
    		'description'	=>			'Crear usuarios'
    	]);

    	Permission::create([
    		'name'			=>			'Ver un usuario',
    		'slug'			=>			'users.show',
    		'description'	=>			'Ver un usuario en especifico'
    	]);


    	Permission::create([
    		'name'			=>			'Editar usuarios',
    		'slug'			=>			'users.update',
    		'description'	=>			'Podra editar a un usuario'
    	]);

        // Users campaign
        Permission::create([
            'name'          =>          'Ver campañas de un usuario',
            'slug'          =>          'users.campaigns.index',
            'description'   =>          'Ver todas las campañas de un usuario'
        ]);

        // Campaigns
        Permission::create([
            'name'          =>          'Ver todas las campañas',
            'slug'          =>          'campaigns.index',
            'description'   =>          'Ver todas las campañas'
        ]);

        Permission::create([
            'name'          =>          'Crear campañas',
            'slug'          =>          'campaigns.store',
            'description'   =>          'Crear campañas'
        ]);

        Permission::create([
            'name'          =>          'Ver una campaña',
            'slug'          =>          'campaigns.show',
            'description'   =>          'Ver una campaña'
        ]);

        Permission::create([
            'name'          =>          'Actualizar campañas',
            'slug'          =>          'campaigns.update',
            'description'   =>          'Actualizar campañas'
        ]);

        Permission::create([
            'name'          =>          'Eliminar campañas',
            'slug'          =>          'campaigns.destroy',
            'description'   =>          'Eliminar campañas'
        ]);

        Permission::create([
            'name'          =>          'Duplicar campañas',
            'slug'          =>          'campaigns.duplicate',
            'description'   =>          'Duplicar campañas'
        ]);

        Permission::create([
            'name'          =>          'Añadir puntos de interes a una campaña',
            'slug'          =>          'campaigns.pointsofinterest.store',
            'description'   =>          'Añadir puntos de interes a una campaña'
        ]);

        Permission::create([
            'name'          =>          'Ver todos los puntos de inters de una campaña',
            'slug'          =>          'campaigns.pointsofinterest.index',
            'description'   =>          'Ver todos los puntos de inters de una campaña'
        ]);

        Permission::create([
            'name'          =>          'Eliminar puntos de inters de una campaña',
            'slug'          =>          'campaigns.pointsofinterest.destroy',
            'description'   =>          'Eliminar puntos de inters de una campaña'
        ]);

        Permission::create([
            'name'          =>          'Añadir poligonos a una campaña',
            'slug'          =>          'campaigns.polygons.store',
            'description'   =>          'Añadir poligonos a una campaña'
        ]);

        Permission::create([
            'name'          =>          'Ver todos los poligonos de una campaña',
            'slug'          =>          'campaigns.polygons.index',
            'description'   =>          'Ver todos los poligonos de una campaña'
        ]);

        Permission::create([
            'name'          =>          'Eliminar poligonos de una campaña',
            'slug'          =>          'campaigns.polygons.destroy',
            'description'   =>          'Eliminar poligonos de una campaña'
        ]);

        Permission::create([
            'name'          =>          'Añadir pantallas a una campaña',
            'slug'          =>          'campaigns.screens.store',
            'description'   =>          'Añadir pantallas a una campaña'
        ]);

        Permission::create([
            'name'          =>          'Ver todas las pantallas de una campaña',
            'slug'          =>          'campaigns.screens.index',
            'description'   =>          'Ver todas las pantallas de una campaña'
        ]);

        Permission::create([
            'name'          =>          'Eliminar pantallas de una campaña',
            'slug'          =>          'campaigns.screens.destroy',
            'description'   =>          'Eliminar pantallas de una campaña'
        ]);

        //Circuits
        Permission::create([
            'name'          =>          'Ver todos los circuitos',
            'slug'          =>          'circuits.index',
            'description'   =>          'Ver todos los circuitos'
        ]);

        Permission::create([
            'name'          =>          'Añadir circuitos',
            'slug'          =>          'circuits.store',
            'description'   =>          'Añadir circuitos'
        ]);

        Permission::create([
            'name'          =>          'Actualizar circuitos',
            'slug'          =>          'circuits.update',
            'description'   =>          'Actualizar circuitos'
        ]);

        Permission::create([
            'name'          =>          'Ver un circuito',
            'slug'          =>          'circuits.show',
            'description'   =>          'Ver un circuito'
        ]);

    	// Companies
    	Permission::create([
    		'name'			=>			'Ver todas la empresas',
    		'slug'			=>			'companies.index',
    		'description'	=>			'Ver todas las empresas'
    	]);

        Permission::create([
            'name'          =>          'Crear empresas',
            'slug'          =>          'companies.store',
            'description'   =>          'Crear empresas'
        ]);

    	Permission::create([
    		'name'			=>			'Ver una empresa',
    		'slug'			=>			'companies.show',
    		'description'	=>			'Ver una empresa'
    	]);

    	Permission::create([
    		'name'			=>			'Actualizar empresas',
    		'slug'			=>			'companies.update',
    		'description'	=>			'Actualizar empresas'
    	]);

        // Countries
        Permission::create([
            'name'          =>          'Ver todos los paises',
            'slug'          =>          'countries.index',
            'description'   =>          'Ver todos los paises'
        ]);

        Permission::create([
            'name'          =>          'Añadir paises',
            'slug'          =>          'countries.store',
            'description'   =>          'Añadir paises'
        ]);

        Permission::create([
            'name'          =>          'Ver un pais',
            'slug'          =>          'countries.show',
            'description'   =>          'Ver un pais'
        ]);

        Permission::create([
            'name'          =>          'Actualizar paises',
            'slug'          =>          'countries.update',
            'description'   =>          'Actualizar paises'
        ]);

        Permission::create([
            'name'          =>          'Eliminar paises',
            'slug'          =>          'countries.destroy',
            'description'   =>          'Eliminar paises'
        ]);

        // Screens
        Permission::create([
            'name'          =>          'Ver pantallas',
            'slug'          =>          'screens.filtered',
            'description'   =>          'Ver pantallas'
        ]);

        Permission::create([
            'name'          =>          'Añadir pantallas',
            'slug'          =>          'screens.store',
            'description'   =>          'Añadir pantallas'
        ]);

        Permission::create([
            'name'          =>          'Ver una pantalla',
            'slug'          =>          'screens.show',
            'description'   =>          'Ver pantallas'
        ]);

        Permission::create([
            'name'          =>          'Actualizar pantallas',
            'slug'          =>          'screens.update',
            'description'   =>          'Actualizar pantallas'
        ]);

        // Tags
        Permission::create([
            'name'          =>          'Ver tags',
            'slug'          =>          'tags.index',
            'description'   =>          'Ver tags'
        ]);

        Permission::create([
            'name'          =>          'Añadir tags',
            'slug'          =>          'tags.store',
            'description'   =>          'Añadir tags'
        ]);

        Permission::create([
            'name'          =>          'Ver un tag',
            'slug'          =>          'tags.show',
            'description'   =>          'Ver un tag'
        ]);

        Permission::create([
            'name'          =>          'Actualizar tags',
            'slug'          =>          'tags.update',
            'description'   =>          'Actualizar tags'
        ]);

        Permission::create([
            'name'          =>          'Eliminar tags',
            'slug'          =>          'tags.destroy',
            'description'   =>          'Eliminar tags'
        ]);


        // OAUTH
        Permission::create([
            'name'          =>          'Passport Authorizations Authorize',
            'slug'          =>          'passport.authorizations.authorize',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Authorizations Approve',
            'slug'          =>          'passport.authorizations.approve',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Authorizations Deny',
            'slug'          =>          'passport.authorizations.deny',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Clients Index',
            'slug'          =>          'passport.clients.index',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Clients Store',
            'slug'          =>          'passport.clients.store',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Clients Destroy',
            'slug'          =>          'passport.clients.destroy',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Clients Update',
            'slug'          =>          'passport.clients.update',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Personal Tokens Index',
            'slug'          =>          'passport.personal.tokens.index',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Personal Tokens Store',
            'slug'          =>          'passport.personal.tokens.store',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Personal Tokens Destroy',
            'slug'          =>          'passport.personal.tokens.destroy',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Scopes Index',
            'slug'          =>          'passport.scopes.index',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Tokens Refresh',
            'slug'          =>          'passport.token.refresh',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Tokens Index',
            'slug'          =>          'passport.tokens.index',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

        Permission::create([
            'name'          =>          'Passport Tokens Destroy',
            'slug'          =>          'passport.tokens.destroy',
            'description'   =>          'Config USER ADMIN CLIENTS'
        ]);

    }
}
