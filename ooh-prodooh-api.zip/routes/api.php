<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

/* USERS */
Route::resource('users', 'User\UserController')->except('create', 'edit', 'destroy');
Route::resource('users.campaigns', 'User\UserCampaignController')->only('index');
Route::get('logout', 'User\UserController@logout')->name('user.logout');
/* COMPANIES */
Route::resource('companies', 'Company\CompanyController')->except('create', 'edit', 'destroy');
/* SCREENS */
Route::resource('screens', 'Screen\ScreenController')->except('create', 'edit', 'destroy', 'index');
Route::post('filtered-screens', 'Screen\ScreenController@filtered_screens')->name('screens.filtered');
/* CIRCUITS */
Route::resource('circuits', 'Circuit\CircuitController')->except('create', 'edit', 'destroy');
/* CAMPAIGNS */
Route::resource('campaigns', 'Campaign\CampaignController')->except('create', 'edit');
Route::resource('campaigns.screens', 'Campaign\CampaignScreenController')->only('index', 'store', 'destroy');
Route::resource('campaigns.polygons', 'Campaign\CampaignPolygonController')->only('store', 'destroy', 'index');
Route::resource('campaigns.pointsofinterest', 'Campaign\CampaignPointOfInterestController')->only('store', 'destroy', 'index');
Route::get('campaigns/{campaign}/duplicate', 'Campaign\CampaignController@duplicate')->name('campaigns.duplicate');
/*TAGS*/
Route::resource('tags', 'Tag\TagController')->except('create', 'edit');
/*COUNTRIES*/
Route::resource('countries', 'Country\CountryController')->except('create', 'edit');

Route::post('oauth/token', '\Laravel\Passport\Http\Controllers\AccessTokenController@issueToken');